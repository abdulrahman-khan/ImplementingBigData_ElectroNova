import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class DailyMapper extends Mapper<Object, Text, Text, CustomWritable> {
    private CustomWritable averageEnergy = new CustomWritable();
    private Text houseID = new Text();

    @Override
    public void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {

        String houseByDate;
        float energyConsumpton;
        CustomWritable cw;

        String[] values = value.toString().split("\t");

        try {
            houseByDate = values[1] + "\t" + values[2];
            energyConsumpton = Float.parseFloat(values[4]);
            cw = new CustomWritable(energyConsumpton);

        } catch (Exception e) {
            houseByDate = "0\t2015-01-30\t00:31:00";
            cw = new CustomWritable();
        }
        context.write(new Text(houseByDate), cw);
    }
}
