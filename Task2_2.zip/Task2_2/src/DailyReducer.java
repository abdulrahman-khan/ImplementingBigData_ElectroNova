import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class DailyReducer extends Reducer<Text, CustomWritable, Text, FloatWritable> {

    @Override
    public void reduce(Text key, Iterable<CustomWritable> values, Context context)
            throws IOException, InterruptedException {

        double dayElectricConsumption = 0;
        CustomWritable cw = new CustomWritable(0);

        for (CustomWritable amount : values) {
            if (cw.getElectricConsumpton() != 0) {
                dayElectricConsumption += amount.getElectricConsumpton();
                cw = new CustomWritable(amount.getElectricConsumpton());
            } else {
                dayElectricConsumption += (cw.getElectricConsumpton() - amount.getElectricConsumpton());
                cw = new CustomWritable(amount.getElectricConsumpton());
            }
        }
        // houseID \t date dayConsumption
        context.write(key, new FloatWritable((float) dayElectricConsumption));
    }
}
