import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class DailyReducer2 extends Reducer<Text, CustomWritable, Text, FloatWritable> {

    @Override
    public void reduce(Text key, Iterable<CustomWritable> values, Context context)
            throws IOException, InterruptedException {

        float dailySum = 0.0f;
        int counter = 0;

        for (CustomWritable amount : values) {
            counter++;
            dailySum = dailySum + amount.getElectricConsumpton();
        }
        float avg = (float) dailySum / counter;
        context.write(key, new FloatWritable(avg));
    }
}