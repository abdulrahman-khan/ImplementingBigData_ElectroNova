import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;


// takes the house ID as a key and finds the daily maximum

public class EnergyReducer2 extends Reducer<Text, CustomWritable, Text, FloatWritable> {

    @Override
    public void reduce(Text key, Iterable<CustomWritable> values, Context context)
            throws IOException, InterruptedException {
        float maxVal = 0.0f;

        for (CustomWritable amount : values) {
            maxVal = Math.max(maxVal, amount.getElectricConsumpton());
        }

        context.write(key, new FloatWritable(maxVal));
    }
}