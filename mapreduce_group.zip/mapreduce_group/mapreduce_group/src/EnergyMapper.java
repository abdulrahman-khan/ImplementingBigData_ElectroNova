import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class EnergyMapper extends Mapper<Object, Text, Text, CustomWritable> {

    private CustomWritable averageEnergy = new CustomWritable();
    private Text houseID = new Text();

    @Override
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

        String houseByDateByHour;
        float energyConsumpton;
        CustomWritable cw;

        String[] values = value.toString().split("\t");

        try {
            houseByDateByHour = values[1] + "\t" + values[2] + "\t" + values[3].substring(0, 2);
            energyConsumpton = Float.parseFloat(values[4]);
            cw = new CustomWritable(energyConsumpton);
        } catch (Exception e) {
            houseByDateByHour = "0\t2015-01-30\t00:31:00";
            cw = new CustomWritable();
        }
        context.write(new Text(houseByDateByHour), cw);
    }
}
