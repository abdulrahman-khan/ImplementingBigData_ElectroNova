import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

// Reducer 1
// takes in house id date hour and calculates the consumption in that hour

public class EnergyReducer extends Reducer<Text, CustomWritable, Text, FloatWritable> {

    @Override
    public void reduce(Text key, Iterable<CustomWritable> values, Context context)
            throws IOException, InterruptedException {

        double hourElectricConsumption = 0;

        CustomWritable cw = null;
        for (CustomWritable amount : values) {
            if (cw.equals(null)) {
                hourElectricConsumption += amount.getElectricConsumpton();
                cw = new CustomWritable(amount.getElectricConsumpton());
            } else {
                hourElectricConsumption += (cw.getElectricConsumpton() - amount.getElectricConsumpton());
                cw = new CustomWritable(amount.getElectricConsumpton());
            }
        }
        context.write(key, new FloatWritable((float) hourElectricConsumption));
    }
}
