import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

// this custom writeable class holds information so that the reducer can calculate the average values
public class CustomWritable implements Writable {
    private float electricConsumpton;


    public CustomWritable() {
        this.electricConsumpton = 0.0f;
    }

    public CustomWritable(float newConsumptionValue) {
        this.electricConsumpton = newConsumptionValue;
    }

    public float getElectricConsumpton() {
        return electricConsumpton;
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(electricConsumpton);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        electricConsumpton = dataInput.readFloat();
    }
}
