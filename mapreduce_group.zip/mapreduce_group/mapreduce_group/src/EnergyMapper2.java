import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class EnergyMapper2 extends Mapper<LongWritable, Text, Text, FloatWritable> {

    @Override
    protected void map(LongWritable key, Text value, Mapper.Context context)
            throws IOException, InterruptedException {

        String[] values = value.toString().split("\\s+");


        String houseID;
        float energyConsumption;

        try {
            houseID = values[0];
            energyConsumption = Float.parseFloat(values[3]);
        } catch (Exception e) {
            houseID = "9999";
            energyConsumption = 0.0F;
        }
        context.write(new Text(houseID), new CustomWritable(energyConsumption));
    }
}
