import java.io.File;
import java.io.IOException;

public class DirectoryCreator {

    public static void main(String args[]) throws IOException {

        for (int i = 2012; i <= 2029; i++) {
            File yearOutput = new File("C:\\Users\\monamoe\\Documents\\1_Work_Stuff\\6_Semester\\1_BigDataStorageManagement\\GroupProject\\output\\energydata\\" + i);

            if (!yearOutput.exists()) {
                if (yearOutput.mkdirs()) {
                    System.out.println(i + " ");
                }
            }

            for (int x = 1; x < 13; x++) {
                File monthOutput = new File("C:\\Users\\monamoe\\Documents\\1_Work_Stuff\\6_Semester\\1_BigDataStorageManagement\\GroupProject\\output\\energydata2\\" + i + "\\" + x);
                if (!monthOutput.exists()) {
                    monthOutput.mkdirs();
                }
            }
        }
    }
}
