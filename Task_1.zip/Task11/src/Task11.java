import java.io.*;
import java.util.Scanner;

public class Task11 {

    public static void main(String args[]) throws IOException {


        String[] fileNames1 = {
                "consumption_1.txt"
                , "consumption_6.txt"
                , "consumption_12.txt"
                , "consumption_15.txt"
                , "consumption_16.txt"
                , "consumption_17.txt"
                , "consumption_18.txt"
        };


        for (int i = 0; i < fileNames1.length; i++) {
            String inputFilePath = "C:\\Users\\monamoe\\Documents\\1_Work_Stuff\\6_Semester\\1_BigDataStorageManagement\\GroupProject\\Dataset\\" + fileNames1[i];

            System.out.println("on file: " + fileNames1[i] + "\t i: " + i + "\t /" + fileNames1.length);
            System.out.println("File Path: " + inputFilePath);

            //input file
            File file = new File(inputFilePath);
            Scanner reader = new Scanner(file);

            // read first line
            String data = reader.nextLine();

            int counter = 0;
            int finishedcounter = 0;

            // read line by line
            while (reader.hasNextLine()) {

                data = reader.nextLine();
//            System.out.println("Looking at Line" + data);

                // line values
                String[] values = data.split("\t");

                // CONDATE
                String[] condate = values[2].split("-");
                String year = condate[0];
                String month = String.valueOf(Integer.parseInt(condate[1]));
                String day = String.valueOf(Integer.parseInt(condate[2]));
//            System.out.println("Year: " + year + "\t Month: " + month);

                // house ID
                String houseID = values[1];
//            System.out.println("houseID: " + houseID);

                // 5 days a month and only 2 months a year per house
                if (Integer.parseInt(day) % 6 == 0 && Integer.parseInt(month) % 6 == 0) {
                    // output file
                    File output = new File("C:\\Users\\monamoe\\Documents\\1_Work_Stuff\\6_Semester\\1_BigDataStorageManagement\\GroupProject\\output\\energydata2\\" + year + "\\" + month + "\\" + houseID + ".txt");

//            System.out.println("Output File Path: " + output.getAbsoluteFile());
                    if (output.exists()) {
                        // append to the file
                        FileWriter fileWriter;
                        BufferedWriter bufferedWriter;
                        try {
                            fileWriter = new FileWriter(output.getAbsoluteFile(), true);
                            bufferedWriter = new BufferedWriter(fileWriter);
                            bufferedWriter.write(data + "\n");
                            bufferedWriter.close();
                            finishedcounter++;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else {
//                System.out.println("File Doesn't Exist!");
                        // create the file with headers
                        if (output.createNewFile()) {
//                    System.out.println("File created: " + output.getName());
                        }

                        // append to the file
                        FileWriter fileWriter;
                        BufferedWriter bufferedWriter;
                        try {
                            fileWriter = new FileWriter(output.getAbsoluteFile(), true);
                            bufferedWriter = new BufferedWriter(fileWriter);

                            bufferedWriter.write("LOG_ID\tHOUSE_ID\tCOND-ATE\tCONHOUR\tENERGY_READING\tFLAG\n");

                            bufferedWriter.write(data + "\n");
                            bufferedWriter.close();
                            finishedcounter++;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    counter++;
//                    System.out.println(counter + "\t" + finishedcounter + "\t\t" + year + "\t" + month);
                }


            }
        }
    }
}
